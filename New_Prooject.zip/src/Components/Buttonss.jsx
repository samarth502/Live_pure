import React from 'react'

const Buttonss = () => {
  return (
    <div className='md:ml-8 md:text-lg lg:text-xl text-white lg:py-3 lg:px-4 md:px-2 md:py-2 md:text-center  xs:py-3 xs:px-4 rounded-lg bg-red-700 hover:bg-black duration-500 font-extrabold'><a href='https://www.liv-pure.com/welcome?hop=dimpleb'>Order Now</a></div>
  )
}

export default Buttonss;