// import React from 'react'
import img1 from "../Image/free.webp"

const NineSection = () => {
  return (
    <div className="w-[100%] mt-14">
        <img src={img1} className="w-full"/>
    </div>
  )
}

export default NineSection