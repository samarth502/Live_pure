// import React from 'react'
import img1 from "..//Image/guarantee.jpeg"

const EightSection = () => {
  return (
    <div className="w[100%]">
        <img src={img1} className="w-full"/>
    </div>
  )
}

export default EightSection